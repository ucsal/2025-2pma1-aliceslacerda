package cms.user;

public class GuestUser extends User {

    public GuestUser(int id, String nome, String email, String password) {
        super(id, nome, email, password);
    }

    @Override
    public void deleteContent(int contentId) {
     
        System.out.println("Guest " + getNome() + " não tem permissão para deletar conteúdo.");
    }

    public void browse() {
        System.out.println("Guest " + getNome() + " navegando como convidado.");
    }
}