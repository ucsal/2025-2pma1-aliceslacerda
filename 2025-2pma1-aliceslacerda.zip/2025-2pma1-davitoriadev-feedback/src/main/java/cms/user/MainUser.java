package cms.user;

public class MainUser {
    public static void main(String[] args) {
        User admin = new AdminUser(1, "Alice", "alice@email.com", "1234");
        User editor = new EditorUser(2, "Bob", "bob@email.com", "5678");
        User guest = new GuestUser(3, "Carol", "carol@email.com", "abcd");

        admin.deleteContent(10);    
        editor.deleteContent(10);   
        guest.deleteContent(10);    

        ((EditorUser) editor).editContent(20);
        ((GuestUser) guest).browse();
    }
}
