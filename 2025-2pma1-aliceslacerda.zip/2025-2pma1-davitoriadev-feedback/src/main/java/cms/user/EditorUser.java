package cms.user;

public class EditorUser extends User {

    public EditorUser(int id, String nome, String email, String password) {
        super(id, nome, email, password);
    }

    @Override
    public void deleteContent(int contentId) {
      
        System.out.println("Editor " + getNome() + " não tem permissão para deletar conteúdo.");
    }

    public void editContent(int contentId) {
        System.out.println("Editor " + getNome() + " editando conteúdo ID: " + contentId);
    }
}